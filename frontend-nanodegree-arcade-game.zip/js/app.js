
//simplify y coordinates for assigning position for enemies
var rowOne = 60; // got these numbers by trial and error.
var rowTwo = 142;
var rowThree = 225;

var lanes = new Array(); // do i need to store these in an array?

lanes.push(rowOne);
lanes.push(rowTwo);
lanes.push(rowThree);

var Player = function() {
    this.sprite = 'images/char-boy.png';
    this.x = 202;
    this.y = 392;

    this.resetPlayer = function() {
        this.x = 202;
        this.y = 392;
    }

    this.getXPosition = function() {
        return this.x;
    }

     this.getYPosition = function() {
        return this.y;
    }

}

Player.prototype.render = function() {
    console.log("player render x "+this.x + " y "+this.y);
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
}

Player.prototype.update = function() {}


Player.prototype.handleInput = function(direction) {
    console.log("handle input ");
    if (direction === 'left' && this.x > 50) {
        this.x = this.x - 101;
        console.log("handle input x "+this.x);
    }
    if (direction === 'right' && this.x < 400) {
        this.x = this.x + 101;
        console.log("handle input x "+this.x);
    }
    if (direction === 'up' && this.y > 40) {
        this.y = this.y - 83;
        console.log("handle input x "+this.x);
    }
    if (direction === 'down' && this.y < 390) {
        this.y = this.y + 83;
        console.log("handle input x "+this.x);
    }
}

var player = new Player();

// Enemies our player must avoid
var Enemy = function() {

    // Variables applied to each of our instances go here,
    // we've provided one for you to get started

    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.x = 0;
    this.y = 0;
    this.sprite = 'images/enemy-bug.png';
    this.setRandomSpeed = function() {
        //console.log("setRandomSpeed", this.speed);
        this.speed = speeds[Math.floor((Math.random() * 5))]; //chooses a random speed from the 5 options.
        // console.log("setRandomSpeed", this.speed);
    }

    this.setRandomLane = function() {
         // console.log("setRandomLane", this.y);
        this.y = lanes[Math.floor((Math.random() * 3))];
        // console.log("setRandomLane", this.y);
    }
    this.setRandomSpeed();
    this.setRandomLane();
}

var speeds = [80, 120, 200, 245, 300];

Enemy.prototype.collision = function() {
    if (((player.getYPosition() === rowOne
            && (this.x < (player.getXPosition() - 5) && this.x < (player.getXPosition() + 20) ))
        || (player.getYPosition() === rowTwo
            && (this.x < (player.getXPosition() - 5) && this.x < (player.getXPosition() + 20) ))
        || (player.getYPosition() === rowThree)
            && (this.x < (player.getXPosition() - 5) && this.x < (player.getXPosition() + 20) )))
         {
         return true;
     }
    return false;
}
// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    if (this.x < 606) {
        this.x = this.x + this.speed * dt;

        if (this.collision()) {
            console.log("Collision!! Enemy x" + this.x + " Enemy y " + this.y)
            console.log("Player X " + player.getXPosition() + " Player Y " + player.getYPosition());

            player.resetPlayer();
        }

    }
    else {
        console.log("into else statment");
        //reset Bug
        this.setRandomLane();
        //console.log("row set");
        this.setRandomSpeed();
        //console.log("speed set");
        this.x = 0;
        //console.log("x set");
        this.x = this.x + this.speed * dt;
        //console.log("reset");
    }

}




// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {

    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
}


//  Create Enemies of varying speed
var enemy1 = new Enemy(0);
var enemy2 = new Enemy(0);
var enemy3 = new Enemy(0);

//Create array to hold the different Enemy types
var allEnemies = new Array();

// Add the enemies to Array
allEnemies.push(enemy1);
allEnemies.push(enemy2);
allEnemies.push(enemy3);

// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.



// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player



// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
